package com.codegym.employeesmanager.service;

import com.codegym.employeesmanager.entity.Employee;

import java.util.List;

public interface EmployService {
        List<Employee> findAll();
        List<Employee> findByName(String name);
        Employee findById(Long id);
        void update(Employee employee);
        void remove(Employee employee);
        void create(Employee employee);
}
