package com.codegym.employeesmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeesManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeesManagerApplication.class, args);
    }

}
